import { motion } from "framer-motion";
import { Link } from "react-router-dom";

export default function AnimeCard({ anime }) {
  return (
    <motion.div
      whileHover={{ scale: 1.05 }}
      className="bg-white dark:bg-gray-800 shadow-xl rounded-2xl p-4 transition-colors"
    >
      <Link to={`/anime/${anime.id}`}>
        <img
          src={anime.image}
          alt={anime.title}
          className="w-full h-48 object-cover rounded-xl"
        />
        <h2 className="mt-2 text-lg font-semibold">{anime.title}</h2>
        <div className="flex flex-wrap gap-2 mt-2">
          {anime.genres.map((genre, index) => (
            <span key={index} className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full">
              {genre}
            </span>
          ))}
        </div>
      </Link>
    </motion.div>
  );
}