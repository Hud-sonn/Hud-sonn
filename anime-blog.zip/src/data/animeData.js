const animeList = [
  {
    id: "1",
    title: "Attack on Titan",
    image: "https://cdn.myanimelist.net/images/anime/10/47347.jpg",
    genres: ["Action", "Drama", "Fantasy"],
    description: "Humans fight titans in a post-apocalyptic world."
  },
  {
    id: "2",
    title: "Demon Slayer",
    image: "https://cdn.myanimelist.net/images/anime/1286/99889.jpg",
    genres: ["Action", "Supernatural"],
    description: "A boy becomes a demon slayer to avenge his family."
  }
];

export default animeList;