import { useParams } from "react-router-dom";
import animeList from "../data/animeData";

export default function AnimeDetail() {
  const { id } = useParams();
  const anime = animeList.find(a => a.id === id);

  return (
    <div className="p-6">
      <img src={anime.image} alt={anime.title} className="w-full max-w-md mx-auto rounded-xl" />
      <h1 className="text-3xl font-bold mt-4">{anime.title}</h1>
      <p className="mt-2">{anime.description}</p>
    </div>
  );
}